package com.example.therealmytravelapp20

import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
//import androidx.compose.material3.Button
import android.widget.Button

class AlbumAdapter(
    private var albumList: ArrayList<Albums>,  // changed to var to update the list
    private val onItemClick: (Albums) -> Unit,
    private val onDelete: (Albums) -> Unit
) : RecyclerView.Adapter<AlbumAdapter.AlbumViewHolder>() {

    class AlbumViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        val albumName: TextView = itemView.findViewById(R.id.tv_travel)
        val deleteButton: Button = itemView.findViewById(R.id.deleteButton)
    }

    override fun getItemCount() = albumList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlbumViewHolder {
        val viewLayout = LayoutInflater.from(parent.context).inflate(
            R.layout.item_layout,
            parent, false
        )
        return AlbumViewHolder(viewLayout)
    }

    override fun onBindViewHolder(holder: AlbumViewHolder, position: Int) {
        val currentAlbum = albumList[position]
        Log.d("AlbumAdapter", "Binding album: ${currentAlbum.albumName}")
        holder.albumName.text = currentAlbum.albumName


        holder.itemView.setOnClickListener {
            onItemClick(currentAlbum)
        }

        holder.deleteButton.setOnClickListener {
            onDelete(currentAlbum)
        }
    }

    // Function to update album list
    fun updateAlbums(newAlbums: List<Albums>) {
        val snapshot = ArrayList(newAlbums)
        albumList.clear()
        albumList.addAll(snapshot)
        notifyDataSetChanged()
    }

    fun removeAt(position: Int) {
        albumList.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, albumList.size)
    }
}
