package com.example.therealmytravelapp20

data class UserProfile(
    val name: String? = null,
    val username: String? = null,
    val bio: String? = null,
    val profilePicUrl: String? = null,
    val albums: List<Albums>? = null
)


