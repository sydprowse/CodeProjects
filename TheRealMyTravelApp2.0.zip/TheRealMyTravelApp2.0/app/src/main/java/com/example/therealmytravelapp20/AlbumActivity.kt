package com.example.therealmytravelapp20

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.database.FirebaseDatabase
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

class AlbumActivity : AppCompatActivity() {
    lateinit var uploadButton: Button
    lateinit var cameraButton: Button
    private lateinit var tripCaption: EditText
    private lateinit var imageRecycler: RecyclerView
    private lateinit var adapter: ImageAdapter
    private lateinit var images: ArrayList<Bitmap>
    private var firebaseUser = Firebase.auth.currentUser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_album)

        uploadButton = findViewById(R.id.upload_btn)
        cameraButton = findViewById(R.id.camera_btn)
        tripCaption = findViewById(R.id.trip_caption)

        firebaseUser = Firebase.auth.currentUser

        val savedTrip = getTrip(this)
        tripCaption.setText(savedTrip)

        uploadButton.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        cameraButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                openCamera()
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE)
            }
        }

        images = ArrayList()
        imageRecycler = findViewById(R.id.imageRecycler)
        imageRecycler.layoutManager = LinearLayoutManager(this)
        adapter = ImageAdapter(images)
        imageRecycler.adapter = adapter

        loadImagesFromDatabase()

        tripCaption.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val bio = tripCaption.text.toString()
                setTrip(this, bio)
            }
        }
    }

    companion object {
        private const val CAMERA_PERMISSION_CODE = 1
    }

    private val takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap: Bitmap? ->
        if (bitmap != null) {
            var base64Image = convertImageToBase64(bitmap)
            saveImageToDatabase(base64Image)
            images.add(bitmap)
            adapter.notifyItemInserted(images.size - 1)
        } else {
            Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCamera() {
        takePictureLauncher.launch(null)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera()
        } else {
            Toast.makeText(this, "Camera permission denied.", Toast.LENGTH_SHORT).show()
        }
    }

    fun convertImageToBase64(bitmap: Bitmap): String {
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.DEFAULT)
    }

    fun saveImageToDatabase(base64Image: String) {
        val albumName: String = intent.getStringExtra("albumName") ?: return
        val albumKey: String = intent.getStringExtra("albumKey") ?: return
        val userIdRaw: String = intent.getStringExtra("UserID") ?: firebaseUser?.uid ?: return
        val userId = userIdRaw.replace(".", "_")
        Log.d("AlbumDebug", "albumName: $albumName, userId: $userId")

        val database = FirebaseDatabase.getInstance()
        val imagesRef = database.getReference("users/$userId/albums/$albumName/images")

        var image = Image(base64Image)

        imagesRef.push().setValue(image)
            .addOnSuccessListener {
                Toast.makeText(this, "Image saved to album", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show()
            }
    }

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, it)
            var base64Image = convertImageToBase64(bitmap)
            saveImageToDatabase(base64Image)
            images.add(bitmap)
            adapter.notifyItemInserted(images.size - 1)
        }
    }

    fun loadImagesFromDatabase() {
        val albumName: String = intent.getStringExtra("albumName") ?: return
        val albumKey: String = intent.getStringExtra("albumKey") ?: return
        val userIdRaw: String = intent.getStringExtra("UserID") ?: firebaseUser?.uid ?: return
        val userId = userIdRaw.replace(".", "_")

        val database = FirebaseDatabase.getInstance()
        val imagesRef = database.getReference("users/$userId/albums/$albumName/images")

        imagesRef.get().addOnSuccessListener { dataSnapshot ->
            for (snapshot in dataSnapshot.children) {
                val image = snapshot.getValue(Image::class.java)
                image?.base64Image?.let {
                    val bitmap = decodeBase64ToBitmap(it)
                    images.add(bitmap)
                    adapter.notifyItemInserted(images.size - 1)
                }
            }
        }
    }

    fun decodeBase64ToBitmap(base64String: String): Bitmap {
        val decodedByteArray = Base64.decode(base64String, Base64.DEFAULT)
        val byteArrayInputStream = ByteArrayInputStream(decodedByteArray)
        return BitmapFactory.decodeStream(byteArrayInputStream)
    }

    private fun setTrip(context: Context, trip: String) {
        val prefs = context.getSharedPreferences("myAppPackage", Context.MODE_PRIVATE)
        prefs.edit().putString("trip", trip).apply()
    }

    private fun getTrip(context: Context): String {
        val prefs = context.getSharedPreferences("myAppPackage", Context.MODE_PRIVATE)
        return prefs.getString("trip", "") ?: ""
    }

    override fun onPause() {
        super.onPause()
        val trip = tripCaption.text.toString()
        setTrip(this, trip)
    }
}
