package com.example.therealmytravelapp20

data class Image(
    var base64Image: String = "" // URL of the image (this will be stored in Firebase)
)
