package com.example.therealmytravelapp20

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.lifecycleScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var testText: TextView
    private lateinit var loginButton: Button
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var credentialManager: CredentialManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        FirebaseApp.initializeApp(this)

        setContentView(R.layout.activity_main)

        loginButton = findViewById(R.id.login_button)
        testText = findViewById(R.id.login_text)

        loginButton.setOnClickListener {
            googleSignInButton()
        }
    }

    private fun googleSignInButton() {
        val credentialManager = CredentialManager.create(this@MainActivity)

        val googleIdOption = GetGoogleIdOption.Builder()
            .setServerClientId(getString(R.string.default_web_client_id))
            .setFilterByAuthorizedAccounts(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        lifecycleScope.launch {
            val result = credentialManager.getCredential(
                context = this@MainActivity,
                request = request
            )

            val credential = result.credential

            if (credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val googleIdToken = googleIdTokenCredential.idToken
                val firebaseCredential =
                    GoogleAuthProvider.getCredential(googleIdToken, null)

                Firebase.auth.signInWithCredential(firebaseCredential)
                    .addOnSuccessListener {
                        val pic = credential.data.get("com.google.android.libraries.identity.googleid.BUNDLE_KEY_PROFILE_PICTURE_URI")
                        val name = credential.data.getString("com.google.android.libraries.identity.googleid.BUNDLE_KEY_DISPLAY_NAME")
                        val username = credential.data.getString("com.google.android.libraries.identity.googleid.BUNDLE_KEY_ID")
                        val firebaseUser = Firebase.auth.currentUser
                        val userID = firebaseUser?.uid

                        val intent = Intent(this@MainActivity, ProfileActivity::class.java)
                        intent.putExtra("ProfilePic", pic.toString())
                        intent.putExtra("Name", name)
                        intent.putExtra("Username", username)
                        intent.putExtra("UserID", userID)
                        startActivity(intent)

                        Toast.makeText(this@MainActivity, "Login successful!", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this@MainActivity, "Login failed.", Toast.LENGTH_SHORT).show()
                        Log.e("AuthError", "Firebase sign-in failed", it)
                    }
            }
        }
    }
}
