package com.example.therealmytravelapp20

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import coil.load

class UploadActivity : AppCompatActivity() {

    private lateinit var uploadButton: Button
    private lateinit var uploadedImageView: ImageView
    

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            uploadedImageView.visibility = ImageView.VISIBLE
            uploadedImageView.load(uri) // Loads image using Coil this is important
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload)

        uploadButton = findViewById(R.id.uploadButton)
        uploadedImageView = findViewById(R.id.uploadedImageView)

        uploadButton.setOnClickListener {
            pickImageLauncher.launch("image/*") //gallery we need to add this to profile
        }
    }
}
