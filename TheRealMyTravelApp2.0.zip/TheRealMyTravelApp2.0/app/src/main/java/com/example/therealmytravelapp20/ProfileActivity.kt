package com.example.therealmytravelapp20

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class ProfileActivity : AppCompatActivity() {

    private lateinit var nameText: TextView
    private lateinit var userText: TextView
    private lateinit var bioText: EditText
    private lateinit var profilePic: ImageView
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AlbumAdapter
    private lateinit var createAlbumBtn: Button
    private lateinit var albumNameInput: EditText
    private lateinit var items: ArrayList<Albums>
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        database = FirebaseDatabase.getInstance().reference

        // Initialize views
        nameText = findViewById(R.id.nametv)
        userText = findViewById(R.id.emailtv)
        bioText = findViewById(R.id.bioET)
        profilePic = findViewById(R.id.avatartv)
        albumNameInput = findViewById(R.id.albumNameInput)
        createAlbumBtn = findViewById(R.id.create_album_btn)

        // Set up user details
        val name = intent.getStringExtra("Name")
        val username = intent.getStringExtra("Username")
        val pic = intent.getStringExtra("ProfilePic")
        val userID = intent.getStringExtra("UserID")

        nameText.text = name
        userText.text = username
        val savedBio = getBio(this)
        bioText.setText(savedBio)

        Glide.with(this)
            .load(pic)
            .placeholder(R.drawable.travel_airplane)
            .into(profilePic)

        items = ArrayList()

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AlbumAdapter(items,
            onItemClick =  { clickedAlbum ->
                val usernameKey = intent.getStringExtra("Username")!!
                    .replace(".", "_")
                val albumIntent = Intent(this@ProfileActivity, AlbumActivity::class.java)
                albumIntent.putExtra("albumName", clickedAlbum.albumName)
                albumIntent.putExtra("albumKey", clickedAlbum.id)
                albumIntent.putExtra("UserID", usernameKey)  // Pass userID to AlbumActivity
            startActivity(albumIntent) },
            onDelete = { albumToDelete ->
                val usernameKey = intent.getStringExtra("Username")!!
                    .replace(".", "_")
                val dbAlbums = database
                    .child("users")
                    .child(usernameKey)
                    .child("albums")

                // 1) remove from Firebase
                dbAlbums.child(albumToDelete.id)
                    .removeValue()
                    .addOnSuccessListener {
                        // 2) then remove from your local list & refresh
                        val idx = items.indexOfFirst { it.id == albumToDelete.id }
                        if (idx >= 0) {
                            items.removeAt(idx)
                            adapter.notifyItemRemoved(idx)
                        }
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Failed to delete album", Toast.LENGTH_SHORT).show()
                    }
            }
        )
        recyclerView.adapter = adapter

        createAlbumBtn.setOnClickListener {
            val albumName = albumNameInput.text.toString().trim()
            if (albumName.isNotEmpty()) {
                val newAlbum = Albums(albumName)
                items.add(newAlbum)
                adapter.notifyItemInserted(items.size - 1)
                albumNameInput.text.clear()

                val username = intent.getStringExtra("Username") ?: return@setOnClickListener
                val userId = username.replace(".", "_")

                val albumRef = database.child("users").child(userId).child("albums")
                //albumRef.push().setValue(newAlbum)
                albumRef.child(albumName).setValue(newAlbum)
                    .addOnSuccessListener {
                        Log.d("Firebase", "New album saved")
                    }
                    .addOnFailureListener {
                        Log.e("Firebase", "Failed to save album", it)
                    }
            } else {
                Toast.makeText(this, "Album name can't be empty", Toast.LENGTH_SHORT).show()
            }
        }

        bioText.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val bio = bioText.text.toString()
                setBio(this, bio)
                saveUserProfileToFirebase()
            }
        }

        loadUserProfileFromFirebase()
    }

    private fun saveUserProfileToFirebase() {
        val name = nameText.text.toString()
        val username = intent.getStringExtra("Username") ?: return
        val bio = bioText.text.toString()
        val profilePicUrl = intent.getStringExtra("ProfilePic")
        val userId = username.replace(".", "_")

        // Save profile info (only)
        val userProfileData = mapOf(
            "name" to name,
            "username" to username,
            "bio" to bio,
            "profilePicUrl" to profilePicUrl
        )

        database.child("users").child(userId).updateChildren(userProfileData)
            .addOnSuccessListener {
                Log.d("Firebase", "User profile info updated without deleting albums")
            }
            .addOnFailureListener {
                Log.e("Firebase", "Failed to update user profile", it)
            }
    }

    private fun loadUserProfileFromFirebase() {
        val username = intent.getStringExtra("Username") ?: return
        val userId = username.replace(".", "_")

        val userRef = database.child("users").child(userId)

        // load basic user info
        userRef.get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.exists()) {
                    val name = snapshot.child("name").getValue(String::class.java)
                    val bio = snapshot.child("bio").getValue(String::class.java)

                    nameText.text = name ?: ""
                    bioText.setText(bio ?: "")

                    // Load albums
                    val albumsSnapshot = snapshot.child("albums")
                    items.clear()
                    for (albumSnap in albumsSnapshot.children) {
                        Log.d("Firebase", "Albums snapshot: ${albumsSnapshot.value}")
                        val album = albumSnap.getValue(Albums::class.java)
                        if (album != null) {
                            album.id = albumSnap.key ?: ""      // store the Firebase key
                            items.add(album)
                            Log.d("Firebase", "Album loaded: ${album.albumName}")
                        } else {
                            Log.w("Firebase", "Failed to parse album: ${albumSnap.value}")
                        }
                    }
                    adapter.updateAlbums(items)
                    //adapter.notifyDataSetChanged()
                } else {
                    Log.d("Firebase", "User not found")
                }
            }
            .addOnFailureListener {
                Log.e("Firebase", "Failed to load user profile", it)
            }
    }


    private fun setBio(context: Context, bio: String) {
        val prefs = context.getSharedPreferences("myAppPackage", Context.MODE_PRIVATE)
        prefs.edit().putString("bio", bio).apply()
    }

    private fun getBio(context: Context): String {
        val prefs = context.getSharedPreferences("myAppPackage", Context.MODE_PRIVATE)
        return prefs.getString("bio", "") ?: ""
    }

    override fun onPause() {
        super.onPause()
        val bio = bioText.text.toString()
        setBio(this, bio)
        saveUserProfileToFirebase()
    }
}
