package com.example.therealmytravelapp20

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DisplayImageActivity : AppCompatActivity() {

    private lateinit var capturedImageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        capturedImageView = findViewById(R.id.capturedImagesLayout)

        // Retrieve the byte array from the intent
        val byteArray = intent.getByteArrayExtra("image_data")
        if (byteArray != null) {
            // Convert byte array to Bitmap
            val bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            capturedImageView.setImageBitmap(bitmap) // Display the image
        } else {
            Toast.makeText(this, "No image data received", Toast.LENGTH_SHORT).show()
        }
    }
}