package com.example.therealmytravelapp20

import android.graphics.Bitmap
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.widget.ImageView
import com.bumptech.glide.Glide

class ImageAdapter(
    private val imageList: ArrayList<Bitmap>
):
    RecyclerView.Adapter<ImageAdapter.ImageViewHolder>() {

    class ImageViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        val imageView : ImageView = itemView.findViewById(R.id.imageView)
    }

    override fun getItemCount() = imageList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val viewLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.image_layout,
            parent,false)
        return ImageViewHolder(viewLayout)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        val currentImage = imageList[position]
        Glide.with(holder.imageView.context)
            .load(currentImage)
            .into(holder.imageView)
    }

}