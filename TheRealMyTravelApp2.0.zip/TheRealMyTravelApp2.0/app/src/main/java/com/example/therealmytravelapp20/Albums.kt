package com.example.therealmytravelapp20

import android.graphics.Bitmap

data class Albums(
    var albumName: String = "", // Default value for Firebase deserialization
    var id: String = ""
)
